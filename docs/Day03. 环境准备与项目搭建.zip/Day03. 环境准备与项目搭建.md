# 业务开发

接下来我们就正式开发业务功能。

## 开发规范

在目前项目中，我们采用的是前后端分离的架构模式：



> **什么是前后端分离**？
> 
> 

在前后端分离架构中，前端与后端各司其职：

- **前端**：负责渲染页面，展示数据

- **后端**：负责提供前端展示所需的数据，例如商品信息、用户信息等



也就是说：后端负责“生产原材料（数据）”，前端负责“把原材料做成成品（界面）”。



### 接口文档



> **什么是接口文档**？
> 
> 

既然前后端分开了，前端要拿数据，就得知道去哪拿、怎么拿、拿到的数据长什么样。接口文档就是一份说明书，这份说明书里就清清楚楚写着：

- 去哪拿（请求地址 URL）

- 怎么拿（请求方式，是 GET 还是 POST）

- 要带什么条件（请求参数，比如“查学号 001 的学生”）

- 拿到的是什么样（返回的数据格式，比如 `{"name":"张三"}`）



> **接口文档有什么用**？
> 
> 

- 接口文档是前后端交互的标准，前后端参考同一份标准，同时开发，效率翻倍。

- 只要前后端都遵循接口文档，前后端写好的代码一定可以正常交互。交互出错，也能快速定位是前端还是后端的责任



在咱们项目中，由于前端是基于接口文档提前写好的，因此我们在开发后端时也**必须严格遵循接口文档**，这样就可以直接与前端交互，实现功能。



在线笔记提供了两份接口文档：

- [保险业务接口文档](https://my.feishu.cn/wiki/VCv6wzhr2i94KCkj7Bwc4GkdnNc)：与保险相关的业务接口，如登录、注册、保险商品查询等

- [智能客服接口文档](https://my.feishu.cn/wiki/XxdQwOlDpiaRRMk2thYcVEOKnte)：与AI智能客服相关接口，如会话管理、对话聊天等



当然，完整的保险业务接口非常多，我们并不需要全都开发，目前只需要做下面几个与保险产品（Product）有关的接口：

- 6\.1\.查询产品列表：[保险业务接口文档](https://my.feishu.cn/wiki/VCv6wzhr2i94KCkj7Bwc4GkdnNc?fromScene=spaceOverview&wiki_all_space_view_source=space_sidebar#share-YzYmdZorLo7vDUxmJrqcobRxnAe)

- 6\.2\.查询推荐候选产品

后续可以继续完成其它接口。



### 开发流程

按照之前的项目结构说明，业务功能要放到`app.modules`包，并且给不同的业务创建子包，例如产品相关业务，就创建一个`product`包。如图：



![image\.png](图片和附件/image%2011.png)

而在`product`下，又包含`router`、`service`、`repository`、`schemas`、`models`等模块，模块间关系如下：



如图中所示：

- `router`、`service`、`repository`之间是依赖关系，`router`依赖于`service`，`service`依赖于`repository`。

- `schemas`是按照接口文档规范定义的请求和响应约束模型，`models`是数据库表映射类，这两类数据在各层间传递，需要先定义出来。

- 开发业务时从底层的`repository`开始，逐层向上开发。





## 查询产品列表

目前访问前端首页，可以看到页面虽然出来了，但数据是没有的：

![image\.png](图片和附件/image%204.png)

这就是缺少后端接口，查不到对应的数据，所以无法渲染。



### 接口信息

对应的接口信息如下：

查询有效的保险产品，可以按产品分类过滤，接口直接返回产品列表。

|请求方式|请求路径|是否需要登录|
|---|---|---|
|`GET`|`/api/v1/products`|否|

**Query 参数**：

|参数|类型|必填|默认值|说明|
|---|---|---|---|---|
|`category`|string|否|无|产品分类；不传时查询全部有效产品|

**请求示例**：

```bash
curl "http://127.0.0.1:8001/api/v1/products?category=medical"
```

**响应字段**：

|字段|类型|说明|
|---|---|---|
|`[]`|array|产品列表|
|`[].id`|number|产品 ID|
|`[].name`|string|产品名称|
|`[].clause_name`|string|主条款文件名|
|`[].category`|string|产品分类|
|`[].insurer`|string|保险公司|
|`[].image_url`|string|产品图片地址|
|`[].description`|string|产品简介|
|`[].min_premium`|string/null|最低年缴保费参考|
|`[].max_premium`|string/null|最高年缴保费参考|
|`[].target_group`|string/null|适用人群|
|`[].highlights`|array|产品亮点|
|`[].status`|string|产品状态|



**响应示例**：

```json
[
  {
    "id": 6,
    "name": "众安尊享e生百万医疗险2026版",
    "clause_name": "众安尊享e生百万医疗险2026版条款.pdf",
    "category": "medical",
    "insurer": "众安保险",
    "image_url": "https://files.huizecdn.com/file3/M00/B0/02/example.png",
    "description": "百万医疗险产品，覆盖住院、特殊门诊等医疗责任。",
    "min_premium": "255.00",
    "max_premium": "1420.00",
    "target_group": "30天-70周岁（1-6类职业）",
    "highlights": ["百万医疗", "医疗保障", "责任免除清晰"],
    "status": "active"
  }
]
```





接下来，我们就按照这个接口文档要求来开发【**查询产品列表**】这个接口。



### Schemas

`schemas`就是接口的请求参数和响应结果约束，严格按照接口文档要求定义即可。根据接口文档，请求参数是`?`拼接的参数，无需定义`schemas`，只要定义响应结果`schemas`即可。

这个接口直接返回产品数组，因此不需要定义分页模型，只需要定义单个产品的响应模型 `ProductResponse`。

然后，新建一个`app.modules.product`包，在其中新建一个`schemas.py`文件：

![image\.png](图片和附件/image%207.png)

内容如下：

```python
from decimal import Decimal
from pydantic import BaseModel, field_validator


class ProductResponse(BaseModel):
    *"""保险产品响应结果"""*
*    *
    *id: int
*    *name: str
*    *clause_name: str
*    *category: str
*    *insurer: str
*    *image_url: str
*    *description: str
*    *min_premium: Decimal | None
*    *max_premium: Decimal | None
*    *target_group: str | None
*    *highlights: list[str]
*    *status: str*
```



### Models

Schema 负责约束接口数据，Model 则负责描述数据库表。`products`表结构如下：

```SQL
CREATE TABLE "products" (
        "id" SERIALNOT NULL,
        "name" VARCHAR(200) NOT NULL,
        "clause_name" VARCHAR(300) NOT NULL,
        "category" VARCHAR(50) NOT NULL,
        "insurer" VARCHAR(120) NOT NULL,
        "image_url" TEXT NULL DEFAULT NULL,
        "description" TEXT NULL DEFAULT NULL,
        "min_premium" NUMERIC(14,2) NULL DEFAULT NULL,
        "max_premium" NUMERIC(14,2) NULL DEFAULT NULL,
        "target_group" VARCHAR(300) NULL DEFAULT NULL,
        "highlights" UNKNOWN NULL DEFAULT NULL,
        "status" VARCHAR(30) NOT NULL DEFAULT 'active',
        "created_at" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updated_at" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY ("id")
)
```

我们只需要参考表结构定义model即可。





#### 统一基类和混入类

SqlAlchemy的数据库表映射类都需要继承共同的**基类**：`Base`，不仅仅是Product业务需要，以后的其它业务模型都需要，所以属于公共父类，应该放到`app.common`包。



我们先定义SqlAlchemy的统一**基类**和**混入类:**

- **基类**：也就是Base类，标记当前类是SqlAlchemy的表相关实体类

- **混入类**：就是提取一些表公共字段，其它表模型类继承了混入类，就省去了对应字段的编写，提高了复用性



我们新建一个`app.common`包，然后新建一个`models.py`文件：

![image\.png](图片和附件/image%2014.png)

内容如下：

```Python
*from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from datetime import datetime
from sqlalchemy import DateTime, func

# SQLAlchemy的基类，所有数据库表模型都必须继承
class Base(DeclarativeBase):
    def __repr__(self) -> str:
        """通用的repr函数，用于控制台输出对象信息"""
        cls_name = self.__class__.__name__
        attrs = {}
        for key, val in vars(self).items():
            if key.startswith("_"):
                continue
            if isinstance(val, datetime):
                attrs[key] = val.strftime("%Y-%m-%d %H:%M:%S")
            else:
                attrs[key] = val
        return f"{cls_name}({attrs})"

# 通用的时间戳【混入类】，这样其它数据模型不用重复定义时间相关字段
class CreateAtMixin:
    # func.now() 会让数据库在插入时自动生成服务器时间（如 PostgreSQL 的 NOW()）
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now()
    )

class UpdateAtMixin:
    # onupdate=func.now() 会在每次数据行被 UPDATE 时，由 SQLAlchemy 自动更新该字段
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
**    )*
```



#### Product模型

然后就是Product模型了，在 `app.modules.product` 包中新建 `models.py`：

![image\.png](图片和附件/image%2021.png)

内容如下：

```python
from decimal import Decimal

from sqlalchemy import ARRAY, BigInteger, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.common.models import Base, CreateAtMixin, UpdateAtMixin


class Product(Base, CreateAtMixin, UpdateAtMixin):
    *"""保险产品"""*

*    *__tablename__ = "products"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    clause_name: Mapped[str] = mapped_column(String(300))
    category: Mapped[str] = mapped_column(String(50))
    insurer: Mapped[str] = mapped_column(String(120))
    image_url: Mapped[str | None] = mapped_column(Text)
    description: Mapped[str | None] = mapped_column(Text)
    min_premium: Mapped[Decimal | None] = mapped_column(Numeric(14, 2))
    max_premium: Mapped[Decimal | None] = mapped_column(Numeric(14, 2))
    target_group: Mapped[str | None] = mapped_column(String(300))
    highlights: Mapped[list[str] | None] = mapped_column(ARRAY(Text))
    status: Mapped[str] = mapped_column(
        String(30),
        default="active",
        server_default="active",
    )
```

需要注意以下几点：

- `Product`继承了`CreateAtMixin` 和 `UpdateAtMixin`，因此这里不需要重复声明 `created_at` 和 `updated_at`。

- 金额字段在数据库中是 `NUMERIC(14, 2)`，Model 使用 `Decimal` 可以避免浮点误差



### Repository

Repository 只负责数据库访问，不处理接口参数，也不组装响应对象。在 `app.modules.product` 包中新建 `repository.py`：

![image\.png](图片和附件/image%2030.png)

内容如下：

```python
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.product.models import Product


class ProductRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def find_by_category(
        self,
        category: str | None = None,
    ) -> list[Product]:
        # 1.组装查询条件
        # 1.1.默认只查询active状态的产品
        conditions = [Product.status == "active"]
        # 1.2.如果有category，则添加category过滤
        if category:
            conditions.append(Product.category == category)

        # 2.查询产品列表
        products = await self.session.scalars(
            select(Product)
            .where(*conditions)
            .order_by(Product.id.asc())
        )
        return products.all()
```



查询只需要执行一条 SQL：根据可选的产品分类组装过滤条件，然后按产品 ID 升序返回全部符合条件的数据。

接口仅展示有效产品，因此默认增加 `status == "active"` 条件。



### Service

Service 负责组织业务流程：开启事务（如果有必要的话）、调用 Repository，并把数据库 Model 转换为接口 Schema。在 `app.modules.product` 包中新建 `service.py`：

![image\.png](图片和附件/image%2033.png)

内容如下：

```python
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.product.repository import ProductRepository
from app.modules.product.schemas import ProductResponse


class ProductService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.repository = ProductRepository(session)

    async def list_products(
        self,
        category: str | None = None,
    ) -> list[Product]:
        return await self.repository.find_by_category(category)
```



### Router

Router 只负责 HTTP 层：声明路径、接收并校验查询参数、注入数据库会话，然后把请求交给 Service。具体请求信息参考接口文档：

**基础信息：**

|请求方式|请求路径|是否需要登录|
|---|---|---|
|`GET`|`/api/v1/products`|否|

**Query 参数**：

|参数|类型|必填|默认值|说明|
|---|---|---|---|---|
|`category`|string|否|无|产品分类；不传时查询全部有效产品|

**响应格式**：`list[ProductResponse]`





在 `app.modules.product` 包中新建 `router.py`：

![image\.png](图片和附件/image%2017.png)

内容如下：

```python
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.infra.database import get_session
from app.modules.product.schemas import ProductResponse
from app.modules.product.service import ProductService

router = APIRouter(prefix="/api/v1/products", tags=["products"])


@router.get("", response_model=list[ProductResponse])
async def list_products(
    category: str | None = None,
    session: AsyncSession = Depends(get_session),
) -> list[ProductResponse]:
    # 1.获取Service
    service = ProductService(session)
    # 2.查询并返回产品列表
    return await service.list_products(category)
```







### 注册路由与测试

最后在 `app.main` 中导入并注册产品 Router：

```python
from app.modules.product.router import router as product_router

# 创建 app 后注册路由
app.include_router(product_router)
```

启动服务后，访问 `http://127.0.0.1:8001/docs` 查看 FastAPI 自动生成的接口文档。

![image\.png](图片和附件/image%202.png)



### 依赖注入

Router中获取service的代码是手动创建对象，如果接口较多，每个接口都手动创建比较麻烦，可以将获取service的代码抽取为函数，通过依赖注入来获取：

```python
async def get_product_service(
    session: AsyncSession = Depends(get_session),
) -> ProductService:
    return ProductService(session)


@router.get("", response_model=list[ProductResponse])
async def list_products(
    category: str | None = None,
    service: ProductService = Depends(get_product_service),
) -> list[ProductResponse]:
    return await service.list_products(category)
```



- Router 依赖 Service，Service 依赖 Session，这些对象都可以通过依赖注入获取：

    - 定义 `get_product_service` 函数，通过依赖注入获取 `session`，再创建 `ProductService`。

    - 在 `list_products` 的参数列表中，通过依赖注入获取 `service`。



依赖注入流程图：

![image\.png](图片和附件/image%2025.png)



## 查询推荐候选产品（作业）

保险推荐真实流程非常复杂，需要抽取所有保险产品的特征点，然后基于用户画像比较特征点来寻找合适方案。不过本案例采用简化版本，直接从数据库查询一批符合用户需求的，然后由AI来推荐。



推荐方案不能直接从全部产品中任意选择，而是要先按照险种和预算筛出一批候选产品，再交给后续推荐流程进行比较。本接口按险种分别查询，每个险种最多返回指定数量的有效产品。



例如：查询要求的保险类型（categories）有`life`、`medical`，每个险种返回数量（`limit_per_category`）为5，则查询的时候就根据`life`查询5个，根据`medical`查询5个，汇总到一起。



### 接口信息

对应的接口信息如下：

按险种和保费条件查询可用于推荐的候选保险产品。

|请求方式|请求路径|是否需要登录|
|---|---|---|
|`GET`|`/api/v1/products/candidates`|否|

**Query 参数**：

|参数|类型|必填|默认值|说明|
|---|---|---|---|---|
|`categories`|string\[\]|是|无|产品分类，可传多个|
|`premium_min`|number|否|无|只返回最低保费小于该值的产品|
|`limit_per_category`|number|否|`5`|每个险种最多返回数量|

**请求示例**：

```bash
curl "http://127.0.0.1:8001/api/v1/products/candidates?categories=medical&categories=critical_illness&premium_min=2000&limit_per_category=5"
```

**响应格式**：`list[ProductResponse]`

响应是产品数组，数组元素字段与查询产品列表接口中的 `items[]` 完全一致，因此不需要再定义一套重复的 Schema。

```json
[
  {
    "id": 6,
    "name": "众安尊享e生百万医疗险2026版",
    "clause_name": "众安尊享e生百万医疗险2026版条款.pdf",
    "category": "medical",
    "insurer": "众安保险",
    "image_url": "https://files.huizecdn.com/file3/M00/B0/02/example.png",
    "description": "百万医疗险产品，覆盖住院、特殊门诊等医疗责任。",
    "min_premium": "255.00",
    "max_premium": "1420.00",
    "target_group": "30天-70周岁（1-6类职业）",
    "highlights": ["百万医疗", "医疗保障"],
    "status": "active"
  }
]
```

### Schemas与Models

该接口返回的仍然是保险产品，只是查询条件和返回数量不同，因此直接复用现有的 `ProductResponse` 和 `Product`，不需要新增 Schema 或 Model。



### Repository

修改 `app.modules.product.repository.py`，先导入 `Decimal`：

```python
from decimal import Decimal
```

然后在 `ProductRepository` 中添加产品查询方法，根据分类和保费查询，还可以限制查询数量：

```python
async def find_limited_by_category(
    self,
    category: str,
    premium_min: Decimal | None,
    limit: int,
) -> list[Product]:
    conditions = [
        Product.status == "active",
        Product.category == category,
    ]
    if premium_min is not None:
        conditions.append(Product.min_premium < premium_min)

    products = await self.session.scalars(
        select(Product)
        .where(*conditions)
        .order_by(
            Product.min_premium.asc().nullslast(),
            Product.id.asc(),
        )
        .limit(limit)
    )
    return products.all()
```

Repository 只负责数据库查询，不关心业务，所以只要接收 `category`、`premium_min` 和 `limit`，执行一条 SQL 并返回结果。

至于要查询哪些险种、每个险种查询一次并最终汇总，这是候选产品筛选的业务流程，放到 Service 中处理。



### Service

修改 `app.modules.product.service.py`，先导入 `Decimal`，然后在 `ProductService` 中添加下面的方法：

```python
from decimal import Decimal

from app.modules.product.models import Product


async def list_candidates(
    self,
    categories: list[str],
    premium_min: Decimal | None,
    limit_per_category: int,
) -> list[Product]:
    candidate_products: list[Product] = []

    for category in dict.fromkeys(categories):
        products = await self.repository.find_limited_by_category(
            category=category,
            premium_min=premium_min,
            limit=limit_per_category,
        )
        candidate_products.extend(products)

    return candidate_products
```

Service 先利用 `dict.fromkeys()` 对险种去重，同时保留原有顺序；然后逐个险种调用 Repository，最后把每次查询得到的 `Product` 汇总到同一个列表中。这里直接返回 `list[Product]`，Router 声明的 `response_model` 会完成响应校验与序列化。



### Router

修改 `app.modules.product.router.py`，补充下面的导入：

```python
from decimal import Decimal
from typing import Annotated
```

然后添加候选产品接口：

```python
@router.get("/candidates", response_model=list[ProductResponse])
async def list_candidates(
    categories: list[str] = Query(min_length=1),
    premium_min: Decimal | None = None,
    limit_per_category: int = 5,
    service: ProductService = Depends(get_product_service),
) -> list[ProductResponse]:
*    *return await service.list_candidates(
        categories=categories,
        premium_min=premium_min,
        limit_per_category=limit_per_category,
    )
```

说明：

- `categories` 没有默认值，因此至少要传一个险种；

- `premium_min` 必须大于 0，

- `limit_per_category` 限制在 1～10 之间，防止一次查询返回过多数据。





